%Laboratorio 6

close all
clc
a = csvread('ECG1kHz.csv',2,0);
f = a(1200:2199,2) + 4;
t = linspace(0,999,1000);

 x = linspace(-pi,pi,1000);
 y = zeros(1,numel(x));
 
ai = [1.04,-3.1,9.04,-3.2,0.6,1.56,-0.3];
bi = [0.15,0.048,0.1106,0.05,0.3,0.2,0.2];
thetai = [-1.8409,-1.0178,-0.8419,-0.666,0.2953,0.71,1.0555];

A = [ai',bi',thetai'];

for i = 1: length(ai)
   y = y + A(i,1)*exp(-(x-A(i,3)).^2./(2*A(i,2)^2)); 
end
figure(1);
hold on;
superplot(x,f,'Un peridodo de la señal ECG',...
     '$\frac{t}{\textrm{ms}}$','$f(t)=f(t+1/\textrm{ms})$');

superplot(x,y,'Señal ECG Aproximada mediante gaussianas',...
    '$\theta$','$g(\theta)$');

Trr = [0.5];
fs = 1000;
muestras = floor(fs*Trr);
w = [];
for k = 1:numel(Trr)
    w = [w, 2*pi*ones(1,muestras(k))/Trr(k)];
end
%w =  2*pi;
duracion = sum(Trr); % intervalo de observación
N = sum(muestras);
theta = zeros(1,N);
z = zeros(1,N);
z(1) = 0;
theta(1) = -pi;
% figure(3)
hold on
for n = 2:N
   theta(n) = mod((w(n-1)/fs + theta(n-1))+pi,2*pi)-pi;
%  theta(n) = mod((w/fs + theta(n-1))+pi,2*pi)-pi;  
  sumatoria = 0;
    for i = 1:7
        sumatoria = sumatoria...
         -(A(i,1)*(theta(n-1)-A(i,3)))*w(n-1)*...
         exp(-(theta(n-1)-A(i,3))^2/(2*A(i,2)^2))/(A(i,2)^2);      
%     sumatoria = sumatoria...
%         -(A(i,1)*(theta(n-1)-A(i,3)))*w*...
%         exp(-(theta(n-1)-A(i,3))^2/(2*A(i,2)^2))/(A(i,2)^2);      
    
    end
    z(n) = z(n-1) + sumatoria/fs;
end

t = linspace(0,duracion,N);
figure(2);
superplot(t,z,[num2str(numel(Trr)),...
    ' periodos de la señal ECG'], ...
    '$t$','$z(t)$');
function radianes = rad(x)
    radianes = ((1/500)*x-1)*pi
end







