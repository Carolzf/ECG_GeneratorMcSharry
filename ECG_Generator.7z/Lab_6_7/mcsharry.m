function [z,theta] = mcsharry(z,theta,w,fs,A) 
%z      :
%Theta  :angulo o muestra, 
%w      :frec angular (es lo que se modificaría con el potenciómetro)
%fs     :
%A      :
    ondas = -(A(:,1).*(theta-A(:,3)))*w.*...
                exp(-(theta-A(:,3)).^2./(2*A(:,2).^2))./(A(:,2).^2);
    z = z + sum(ondas)/fs;
    theta = mod((w/fs + theta)+pi,2*pi)-pi;
end
