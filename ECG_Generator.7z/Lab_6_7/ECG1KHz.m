close all
clc
a = csvread('ECG1kHz.csv',2,0);
f = a(1200:2199,2) + 4;
t = linspace(0,999,1000);
superplot(t,f,'Un peridodo de la señal ECG',...
    '$\frac{t}{\textrm{ms}}$','$f(t)=f(t+1/\textrm{ms})$');

% x = [0,320,339,367,394,413,999];
% y = [0,0,-0.96,9.04,-1.12,0,0];
% m = diff(y)./diff(x);
